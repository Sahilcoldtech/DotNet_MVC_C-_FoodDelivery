﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastFood.Models
{
    public class Item
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public int CategoryId { get; set; } 
        public Category Category { get; set; } 
        public int SubCategoryId { get; set; }
        public SubCategory SubCategory { get; set; }
    }
}
